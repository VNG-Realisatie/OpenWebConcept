<?php
	class NewProjectUpdater {

		public function __construct() {

			require __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

			$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
				'https://bitbucket.org/gemeenteheerenveen/docker-basis',
				OWC_PLUGIN_FILE,
				'docker-basis'
			);

			$myUpdateChecker->setAuthentication(array(
				'consumer_key' 		=> 'HSYE4jhZWSfM5z93Ka',
				'consumer_secret' 	=> 'F96Acfn2FrUYx9Bb5Y6SuBAKjujg5bJb',
			));

			$myUpdateChecker->setBranch('master');

		}

	}
	// new NewProjectUpdater();